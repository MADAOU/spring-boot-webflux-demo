var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "37668",
        "ok": "11249",
        "ko": "26419"
    },
    "minResponseTime": {
        "total": "365",
        "ok": "365",
        "ko": "999"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "59986",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "10968",
        "ok": "12205",
        "ko": "10441"
    },
    "standardDeviation": {
        "total": "19083",
        "ok": "11408",
        "ko": "21514"
    },
    "percentiles1": {
        "total": "1180",
        "ok": "8943",
        "ko": "1070"
    },
    "percentiles2": {
        "total": "10339",
        "ok": "17306",
        "ko": "1203"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "35589",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60003",
        "ok": "50897",
        "ko": "60003"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 123,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 257,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10869,
    "percentage": 29
},
    "group4": {
    "name": "failed",
    "count": 26419,
    "percentage": 70
},
    "meanNumberOfRequestsPerSecond": {
        "total": "125.56",
        "ok": "37.497",
        "ko": "88.063"
    }
},
contents: {
"req_adduser-api-2f2db": {
        type: "REQUEST",
        name: "AddUser-API",
path: "AddUser-API",
pathFormatted: "req_adduser-api-2f2db",
stats: {
    "name": "AddUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "7109",
        "ko": "1891"
    },
    "minResponseTime": {
        "total": "433",
        "ok": "433",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60028",
        "ok": "59986",
        "ko": "60028"
    },
    "meanResponseTime": {
        "total": "20368",
        "ok": "12262",
        "ko": "50841"
    },
    "standardDeviation": {
        "total": "21212",
        "ok": "11647",
        "ko": "21352"
    },
    "percentiles1": {
        "total": "11667",
        "ok": "8524",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "30257",
        "ok": "17693",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "35909",
        "ko": "60003"
    },
    "percentiles4": {
        "total": "60003",
        "ok": "51149",
        "ko": "60009"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 97,
    "percentage": 1
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 171,
    "percentage": 2
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6841,
    "percentage": 76
},
    "group4": {
    "name": "failed",
    "count": 1891,
    "percentage": 21
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30",
        "ok": "23.697",
        "ko": "6.303"
    }
}
    },"req_getuser-api-96960": {
        type: "REQUEST",
        name: "GetUser-API",
path: "GetUser-API",
pathFormatted: "req_getuser-api-96960",
stats: {
    "name": "GetUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "3039",
        "ko": "5961"
    },
    "minResponseTime": {
        "total": "495",
        "ok": "495",
        "ko": "999"
    },
    "maxResponseTime": {
        "total": "60027",
        "ok": "59801",
        "ko": "60027"
    },
    "meanResponseTime": {
        "total": "15183",
        "ok": "11673",
        "ko": "16973"
    },
    "standardDeviation": {
        "total": "22251",
        "ok": "10846",
        "ko": "26040"
    },
    "percentiles1": {
        "total": "1591",
        "ok": "8802",
        "ko": "1116"
    },
    "percentiles2": {
        "total": "17932",
        "ok": "16230",
        "ko": "60000"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "34508",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60004",
        "ok": "49338",
        "ko": "60005"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 20,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 55,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 2964,
    "percentage": 33
},
    "group4": {
    "name": "failed",
    "count": 5961,
    "percentage": 66
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30",
        "ok": "10.13",
        "ko": "19.87"
    }
}
    },"req_listtusers-api-699d1": {
        type: "REQUEST",
        name: "ListtUsers-API",
path: "ListtUsers-API",
pathFormatted: "req_listtusers-api-699d1",
stats: {
    "name": "ListtUsers-API",
    "numberOfRequests": {
        "total": "1800",
        "ok": "318",
        "ko": "1482"
    },
    "minResponseTime": {
        "total": "365",
        "ok": "365",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "58600",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "9729",
        "ok": "11894",
        "ko": "9264"
    },
    "standardDeviation": {
        "total": "19147",
        "ok": "11516",
        "ko": "20387"
    },
    "percentiles1": {
        "total": "1108",
        "ok": "8909",
        "ko": "1057"
    },
    "percentiles2": {
        "total": "2183",
        "ok": "16823",
        "ko": "1195"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "35974",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60003",
        "ok": "49757",
        "ko": "60004"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 6,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 19,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 293,
    "percentage": 16
},
    "group4": {
    "name": "failed",
    "count": 1482,
    "percentage": 82
},
    "meanNumberOfRequestsPerSecond": {
        "total": "6",
        "ok": "1.06",
        "ko": "4.94"
    }
}
    },"req_updateuser-api-b270e": {
        type: "REQUEST",
        name: "UpdateUser-API",
path: "UpdateUser-API",
pathFormatted: "req_updateuser-api-b270e",
stats: {
    "name": "UpdateUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "705",
        "ko": "8295"
    },
    "minResponseTime": {
        "total": "816",
        "ok": "816",
        "ko": "999"
    },
    "maxResponseTime": {
        "total": "60019",
        "ok": "59613",
        "ko": "60019"
    },
    "meanResponseTime": {
        "total": "6280",
        "ok": "13815",
        "ko": "5639"
    },
    "standardDeviation": {
        "total": "15611",
        "ok": "11294",
        "ko": "15759"
    },
    "percentiles1": {
        "total": "1054",
        "ok": "12476",
        "ko": "1026"
    },
    "percentiles2": {
        "total": "1197",
        "ok": "18250",
        "ko": "1167"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "35892",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "56777",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 12,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 693,
    "percentage": 8
},
    "group4": {
    "name": "failed",
    "count": 8295,
    "percentage": 92
},
    "meanNumberOfRequestsPerSecond": {
        "total": "30",
        "ok": "2.35",
        "ko": "27.65"
    }
}
    },"req_removeuser-api-ea94f": {
        type: "REQUEST",
        name: "RemoveUser-API",
path: "RemoveUser-API",
pathFormatted: "req_removeuser-api-ea94f",
stats: {
    "name": "RemoveUser-API",
    "numberOfRequests": {
        "total": "8868",
        "ok": "78",
        "ko": "8790"
    },
    "minResponseTime": {
        "total": "999",
        "ok": "2089",
        "ko": "999"
    },
    "maxResponseTime": {
        "total": "60017",
        "ok": "51934",
        "ko": "60017"
    },
    "meanResponseTime": {
        "total": "2159",
        "ok": "14343",
        "ko": "2051"
    },
    "standardDeviation": {
        "total": "7613",
        "ok": "9495",
        "ko": "7506"
    },
    "percentiles1": {
        "total": "1039",
        "ok": "12743",
        "ko": "1036"
    },
    "percentiles2": {
        "total": "1158",
        "ok": "18524",
        "ko": "1156"
    },
    "percentiles3": {
        "total": "1293",
        "ok": "31648",
        "ko": "1287"
    },
    "percentiles4": {
        "total": "60001",
        "ok": "43169",
        "ko": "60001"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 78,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 8790,
    "percentage": 99
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.56",
        "ok": "0.26",
        "ko": "29.3"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
