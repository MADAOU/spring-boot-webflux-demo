var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "21358",
        "ok": "11694",
        "ko": "9664"
    },
    "minResponseTime": {
        "total": "344",
        "ok": "344",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "59960",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "19616",
        "ok": "14301",
        "ko": "26048"
    },
    "standardDeviation": {
        "total": "22792",
        "ok": "13705",
        "ko": "29074"
    },
    "percentiles1": {
        "total": "7156",
        "ok": "9580",
        "ko": "1005"
    },
    "percentiles2": {
        "total": "33793",
        "ok": "19860",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "45731",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60004",
        "ok": "56795",
        "ko": "60005"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 109,
    "percentage": 1
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 160,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 11425,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "count": 9664,
    "percentage": 45
},
    "meanNumberOfRequestsPerSecond": {
        "total": "71.193",
        "ok": "38.98",
        "ko": "32.213"
    }
},
contents: {
"req_adduser-api-2f2db": {
        type: "REQUEST",
        name: "AddUser-API",
path: "AddUser-API",
pathFormatted: "req_adduser-api-2f2db",
stats: {
    "name": "AddUser-API",
    "numberOfRequests": {
        "total": "8846",
        "ok": "7538",
        "ko": "1308"
    },
    "minResponseTime": {
        "total": "344",
        "ok": "344",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60010",
        "ok": "59960",
        "ko": "60010"
    },
    "meanResponseTime": {
        "total": "20749",
        "ok": "14235",
        "ko": "58288"
    },
    "standardDeviation": {
        "total": "20450",
        "ok": "13667",
        "ko": "9909"
    },
    "percentiles1": {
        "total": "13042",
        "ok": "9336",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "31017",
        "ok": "19977",
        "ko": "60002"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "45412",
        "ko": "60004"
    },
    "percentiles4": {
        "total": "60003",
        "ok": "56134",
        "ko": "60006"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 101,
    "percentage": 1
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 115,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 7322,
    "percentage": 83
},
    "group4": {
    "name": "failed",
    "count": 1308,
    "percentage": 15
},
    "meanNumberOfRequestsPerSecond": {
        "total": "29.487",
        "ok": "25.127",
        "ko": "4.36"
    }
}
    },"req_getuser-api-96960": {
        type: "REQUEST",
        name: "GetUser-API",
path: "GetUser-API",
pathFormatted: "req_getuser-api-96960",
stats: {
    "name": "GetUser-API",
    "numberOfRequests": {
        "total": "6125",
        "ok": "3122",
        "ko": "3003"
    },
    "minResponseTime": {
        "total": "346",
        "ok": "346",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60011",
        "ok": "59960",
        "ko": "60011"
    },
    "meanResponseTime": {
        "total": "25794",
        "ok": "14103",
        "ko": "37947"
    },
    "standardDeviation": {
        "total": "25042",
        "ok": "13549",
        "ko": "28256"
    },
    "percentiles1": {
        "total": "14645",
        "ok": "9558",
        "ko": "60001"
    },
    "percentiles2": {
        "total": "60001",
        "ok": "19340",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "45304",
        "ko": "60003"
    },
    "percentiles4": {
        "total": "60004",
        "ok": "57239",
        "ko": "60005"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 5,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 29,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3088,
    "percentage": 50
},
    "group4": {
    "name": "failed",
    "count": 3003,
    "percentage": 49
},
    "meanNumberOfRequestsPerSecond": {
        "total": "20.417",
        "ok": "10.407",
        "ko": "10.01"
    }
}
    },"req_listtusers-api-699d1": {
        type: "REQUEST",
        name: "ListtUsers-API",
path: "ListtUsers-API",
pathFormatted: "req_listtusers-api-699d1",
stats: {
    "name": "ListtUsers-API",
    "numberOfRequests": {
        "total": "875",
        "ok": "313",
        "ko": "562"
    },
    "minResponseTime": {
        "total": "387",
        "ok": "387",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60007",
        "ok": "59932",
        "ko": "60007"
    },
    "meanResponseTime": {
        "total": "19316",
        "ok": "14687",
        "ko": "21894"
    },
    "standardDeviation": {
        "total": "24477",
        "ok": "14565",
        "ko": "28215"
    },
    "percentiles1": {
        "total": "2831",
        "ok": "10796",
        "ko": "1004"
    },
    "percentiles2": {
        "total": "45240",
        "ok": "19265",
        "ko": "60001"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "47328",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60003",
        "ok": "58305",
        "ko": "60004"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 3,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 11,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 299,
    "percentage": 34
},
    "group4": {
    "name": "failed",
    "count": 562,
    "percentage": 64
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.917",
        "ok": "1.043",
        "ko": "1.873"
    }
}
    },"req_updateuser-api-b270e": {
        type: "REQUEST",
        name: "UpdateUser-API",
path: "UpdateUser-API",
pathFormatted: "req_updateuser-api-b270e",
stats: {
    "name": "UpdateUser-API",
    "numberOfRequests": {
        "total": "3333",
        "ok": "653",
        "ko": "2680"
    },
    "minResponseTime": {
        "total": "937",
        "ok": "937",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60034",
        "ok": "59928",
        "ko": "60034"
    },
    "meanResponseTime": {
        "total": "14639",
        "ok": "15307",
        "ko": "14476"
    },
    "standardDeviation": {
        "total": "23063",
        "ok": "14034",
        "ko": "24766"
    },
    "percentiles1": {
        "total": "1004",
        "ok": "10751",
        "ko": "1003"
    },
    "percentiles2": {
        "total": "16672",
        "ok": "20429",
        "ko": "1012"
    },
    "percentiles3": {
        "total": "60002",
        "ok": "48619",
        "ko": "60002"
    },
    "percentiles4": {
        "total": "60004",
        "ok": "57428",
        "ko": "60004"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 4,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 649,
    "percentage": 19
},
    "group4": {
    "name": "failed",
    "count": 2680,
    "percentage": 80
},
    "meanNumberOfRequestsPerSecond": {
        "total": "11.11",
        "ok": "2.177",
        "ko": "8.933"
    }
}
    },"req_removeuser-api-ea94f": {
        type: "REQUEST",
        name: "RemoveUser-API",
path: "RemoveUser-API",
pathFormatted: "req_removeuser-api-ea94f",
stats: {
    "name": "RemoveUser-API",
    "numberOfRequests": {
        "total": "2179",
        "ok": "68",
        "ko": "2111"
    },
    "minResponseTime": {
        "total": "973",
        "ok": "973",
        "ko": "1000"
    },
    "maxResponseTime": {
        "total": "60013",
        "ok": "59785",
        "ko": "60013"
    },
    "meanResponseTime": {
        "total": "5391",
        "ok": "19275",
        "ko": "4944"
    },
    "standardDeviation": {
        "total": "14982",
        "ok": "16076",
        "ko": "14730"
    },
    "percentiles1": {
        "total": "1002",
        "ok": "13115",
        "ko": "1002"
    },
    "percentiles2": {
        "total": "1004",
        "ok": "30838",
        "ko": "1004"
    },
    "percentiles3": {
        "total": "60001",
        "ok": "49939",
        "ko": "60001"
    },
    "percentiles4": {
        "total": "60002",
        "ok": "58552",
        "ko": "60002"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 67,
    "percentage": 3
},
    "group4": {
    "name": "failed",
    "count": 2111,
    "percentage": 97
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.263",
        "ok": "0.227",
        "ko": "7.037"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
