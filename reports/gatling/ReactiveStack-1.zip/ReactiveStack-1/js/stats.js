var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "37800",
        "ok": "37800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "312",
        "ok": "312",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17615",
        "ok": "17615",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9704",
        "ok": "9704",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2549",
        "ok": "2549",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9942",
        "ok": "9942",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11129",
        "ok": "11129",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13470",
        "ok": "13470",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15613",
        "ok": "15613",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 56,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 70,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 37674,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "154.286",
        "ok": "154.286",
        "ko": "-"
    }
},
contents: {
"req_rxadduser-api-9b84b": {
        type: "REQUEST",
        name: "RxAddUser-API",
path: "RxAddUser-API",
pathFormatted: "req_rxadduser-api-9b84b",
stats: {
    "name": "RxAddUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "9000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "1477",
        "ok": "1477",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17492",
        "ok": "17492",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10952",
        "ok": "10952",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2734",
        "ok": "2734",
        "ko": "-"
    },
    "percentiles1": {
        "total": "11065",
        "ok": "11065",
        "ko": "-"
    },
    "percentiles2": {
        "total": "12754",
        "ok": "12754",
        "ko": "-"
    },
    "percentiles3": {
        "total": "15386",
        "ok": "15386",
        "ko": "-"
    },
    "percentiles4": {
        "total": "16706",
        "ok": "16706",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9000,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.735",
        "ok": "36.735",
        "ko": "-"
    }
}
    },"req_rxgetuser-api-c5a95": {
        type: "REQUEST",
        name: "RxGetUser-API",
path: "RxGetUser-API",
pathFormatted: "req_rxgetuser-api-c5a95",
stats: {
    "name": "RxGetUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "9000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7471",
        "ok": "7471",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "17615",
        "ok": "17615",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10750",
        "ok": "10750",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1415",
        "ok": "1415",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10552",
        "ok": "10552",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11564",
        "ok": "11564",
        "ko": "-"
    },
    "percentiles3": {
        "total": "13275",
        "ok": "13275",
        "ko": "-"
    },
    "percentiles4": {
        "total": "15074",
        "ok": "15074",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9000,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.735",
        "ok": "36.735",
        "ko": "-"
    }
}
    },"req_rxlisttusers-ap-4b038": {
        type: "REQUEST",
        name: "RxListtUsers-API",
path: "RxListtUsers-API",
pathFormatted: "req_rxlisttusers-ap-4b038",
stats: {
    "name": "RxListtUsers-API",
    "numberOfRequests": {
        "total": "1800",
        "ok": "1800",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "7493",
        "ok": "7493",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15039",
        "ok": "15039",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "10413",
        "ok": "10413",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1136",
        "ok": "1136",
        "ko": "-"
    },
    "percentiles1": {
        "total": "10287",
        "ok": "10287",
        "ko": "-"
    },
    "percentiles2": {
        "total": "11036",
        "ok": "11036",
        "ko": "-"
    },
    "percentiles3": {
        "total": "12516",
        "ok": "12516",
        "ko": "-"
    },
    "percentiles4": {
        "total": "13388",
        "ok": "13388",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1800,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "7.347",
        "ok": "7.347",
        "ko": "-"
    }
}
    },"req_rxupdateuser-ap-2a512": {
        type: "REQUEST",
        name: "RxUpdateUser-API",
path: "RxUpdateUser-API",
pathFormatted: "req_rxupdateuser-ap-2a512",
stats: {
    "name": "RxUpdateUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "9000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "4818",
        "ok": "4818",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "15070",
        "ok": "15070",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "9834",
        "ok": "9834",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1234",
        "ok": "1234",
        "ko": "-"
    },
    "percentiles1": {
        "total": "9819",
        "ok": "9819",
        "ko": "-"
    },
    "percentiles2": {
        "total": "10614",
        "ok": "10614",
        "ko": "-"
    },
    "percentiles3": {
        "total": "11987",
        "ok": "11987",
        "ko": "-"
    },
    "percentiles4": {
        "total": "12836",
        "ok": "12836",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9000,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.735",
        "ok": "36.735",
        "ko": "-"
    }
}
    },"req_rxremoveuser-ap-a8cd9": {
        type: "REQUEST",
        name: "RxRemoveUser-API",
path: "RxRemoveUser-API",
pathFormatted: "req_rxremoveuser-ap-a8cd9",
stats: {
    "name": "RxRemoveUser-API",
    "numberOfRequests": {
        "total": "9000",
        "ok": "9000",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "312",
        "ok": "312",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "13273",
        "ok": "13273",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "7140",
        "ok": "7140",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2585",
        "ok": "2585",
        "ko": "-"
    },
    "percentiles1": {
        "total": "7486",
        "ok": "7486",
        "ko": "-"
    },
    "percentiles2": {
        "total": "9038",
        "ok": "9038",
        "ko": "-"
    },
    "percentiles3": {
        "total": "10891",
        "ok": "10891",
        "ko": "-"
    },
    "percentiles4": {
        "total": "11928",
        "ok": "11928",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 56,
    "percentage": 1
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 70,
    "percentage": 1
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8874,
    "percentage": 99
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "36.735",
        "ok": "36.735",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
